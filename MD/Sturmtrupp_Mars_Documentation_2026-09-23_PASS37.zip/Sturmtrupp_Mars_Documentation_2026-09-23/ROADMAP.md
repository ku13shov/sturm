# STURMTRUPP MARS — GODOT 4 REMAKE ROADMAP

## 1. Project Goal

Create a strict 3D remake of **Sturmtrupp Mars (2007)** in Godot 4 for Android.

The original Java game and its binary data are the reconstruction source. Godot is a new
implementation and must not reproduce the legacy Java architecture merely because the
original code used obfuscated/global arrays.

## 2. Non-Negotiable Rules

1. **Do not invent original data.** Unknown values remain `UNRESOLVED` or `TEMPORARY_BALANCE`.
2. **Preserve original behavior first.** Reproduce integer division, fixed-point behavior,
   percentage resistance, grid movement, timers, and other observed semantics before modernization.
3. **Separate data, gameplay logic, and presentation.**
4. **Do not copy legacy Java architecture into Godot.**
5. Every reconstructed value has a confidence/status:
   - `ORIGINAL_CONFIRMED`
   - `ORIGINAL_INFERRED`
   - `TEMPORARY_BALANCE`
   - `UNRESOLVED`
6. A numerical coincidence is not evidence. A value becomes confirmed only when the relevant
   source → consumer → runtime chain is demonstrated.
7. Historical research belongs in `RESEARCH.md`; current facts belong in `SOURCE_OF_TRUTH.md`.

## 3. Current Confirmed Reconstruction Inputs

### Enemy data

- `rA` is loaded from binary `a` through `HG.B(InputStream)`.
- `rA` is `int[9][16]`.
- Block offset: `12984`.
- Nine rows correspond to enemy IDs `70–78`.
- Confirmed enemy damage: `rA[][4]`.
- Confirmed enemy attack range: `rA[][12]`.
- Confirmed resistance fields:
  - `rA[][5]` = bullet resistance
  - `rA[][6]` = energy resistance
  - `rA[][7]` = fire resistance
- Enemy initial HP is confirmed through the current consumer chain documented in
  `SOURCE_OF_TRUTH.md` / `RESEARCH.md`.

### Buildings

- Twelve building records are in `oA : int[12][9]`.
- `oA` block offset: `11518`.
- Building IDs:
  `151, 153, 155, 157, 159, 161, 163, 165, 167, 169, 171, 173`.
- Building Max HP is confirmed.
- Building Cost is confirmed.
- `rA` is **enemy** combat data and must not be reused as a building/turret table.
- Universal turret Damage / Range / Fire Rate are **not yet fully confirmed**.

### `mA`

The 2026-09-23 forensic pass supersedes the old `[4]/[5]` Damage/Range hypothesis.

For the conventional `lA` combat pipeline:

- `mA[type][6..8]` = three damage components — `ORIGINAL_CONFIRMED`.
- low16 `mA[type][14]` = target/engagement range — `ORIGINAL_CONFIRMED`.
- `mA[type][15]` = attack cooldown/interval — `ORIGINAL_CONFIRMED`.
- `mA[type][4]` is UI-labelled `ОЖ`; runtime HP semantics remain `ORIGINAL_INFERRED`.
- `mA[type][5]` is not a confirmed Damage/Range field; exact semantics remain `UNRESOLVED`.

Rows 36..44 (the previously targeted 13/14/15 blocks) contain zero attack components,
range `-1`, and cooldown `-1`, so they do not use this conventional attack path.


## 4. Current Research Blockers

1. Map building IDs `151..173` through the actual runtime construction/spawn/upgrade path.
2. Determine which building records instantiate a conventional `lA/mA` combat entity and
   which use `oA` / static / special-effect logic.
3. For every combat-capable building, connect its runtime type to the now-confirmed:
   - Damage components `mA[][6..8]`,
   - Range low16 `mA[][14]`,
   - Cooldown `mA[][15]`,
   or prove a separate special/static path.
4. Finish the still-unresolved special/static consumers, including values previously seen
   around building IDs `159` / `161` and other `oA` effects.
5. Close exact semantics of `mA[][4]` and `mA[][5]` only if required by gameplay fidelity.

The old blocker `13/14/15 → mA[][4/5] → Damage/Range` is retired.


## 5. Godot Target Architecture

The Godot implementation should use clean domain structures rather than Java arrays:

```text
data/
  game_balance.gd

systems/
  combat/
  navigation/
  economy/
  waves/
  upgrades/

entities/
  enemies/
  buildings/

scenes/
  world/
  enemies/
  buildings/
  ui/
```

The exact final folder structure can evolve, but data, gameplay systems, entities, scenes, and
presentation must remain explicitly separated.

## 6. Development Order

### DEV-01 — Source/data foundation
- Freeze the current source-of-truth tables.
- Keep all unresolved fields explicitly marked.
- Establish `game_balance.gd` data structures.

**Done when:** confirmed source values can be represented without inserting invented values.

### DEV-02 — Map/grid foundation
- Implement the 64×64 map/grid representation.
- Preserve original grid semantics.

**Done when:** map coordinates and grid behavior match the reconstructed original rules.

### DEV-03 — Navigation
- Implement the navigation/movement system.
- Preserve grid-based movement behavior.

**Done when:** enemy movement follows reconstructed navigation rules.

### DEV-04 — Enemy foundation
- Implement `BugBase`.
- Add the nine enemy AI/data profiles only from confirmed/inferred source data.

**Done when:** each enemy type has a traceable data source and no invented original values.

### DEV-05 — Building foundation
- Implement `BuildingBase`.
- Implement building HP/cost from confirmed data.
- Keep turret combat fields unresolved until the forensic blocker is closed.

**Done when:** all twelve building records load with confirmed HP/cost and explicit unresolved combat fields.

### DEV-06 — Combat system
- Implement resistance handling using the confirmed Bullet/Energy/Fire model.
- Implement enemy damage/range from `rA`.
- Add defensive-structure combat only after the `mA` consumer chain is proven.

**Done when:** enemy combat matches the reconstructed source semantics and turret behavior is sourced.

### DEV-07 — Waves
- Implement `WaveManager`.
- Do not hardcode unresolved wave data as original.

### DEV-08 — Economy
- Implement currency and spending systems.
- Keep unresolved costs explicitly marked.

### DEV-09 — Upgrades
- Implement upgrade data/logic only where the source chain is established.

### DEV-10 — Power-ups
- Implement power-up behavior after source semantics are established.

### DEV-11 — 3D World
- Build the 3D presentation layer over the reconstructed gameplay systems.

### DEV-12 — UI
- Reconstruct UI behavior and presentation separately from gameplay data.

### DEV-13 — VFX / Audio
- Add effects and audio without changing gameplay semantics.

### DEV-14 — Save / Load
- Implement persistence after core state structures are stable.

### DEV-15 — Balance / Regression
- Run regression tests against all confirmed source behavior.
- Review every remaining `UNRESOLVED` value before calling the remake source-faithful.

## 7. Definition of Done

A subsystem is complete only when:

- its original behavior is traced or explicitly classified as an inference;
- source data and runtime consumers are documented;
- no temporary balance value is mislabeled as original;
- Godot implementation is separated from legacy Java architecture;
- regression tests cover the reconstructed behavior.

## 8. Current Next Step

**FORENSIC TARGET — BUILDING ID → ACTIVATION/EFFECT PATH**

Trace the twelve building IDs:

```text
151, 153, 155, 157, 159, 161,
163, 165, 167, 169, 171, 173
```

through both verified layers:

```text
construction / spawn / upgrade
    ↓
runtime lA entity and mA type, OR oA/static-effect state

UI/event activation
    ↓
HG → C.F(index)
    ↓
oA[index][8] runtime state
    ↓
C.O() / C.P() / C.M() / related consumer
    ↓
HP mutation / target state / geometry / timer
```

For conventional entities, verify per-building linkage to the already confirmed pipeline:

```text
mA[type][6..8] → damage components
low16 mA[type][14] → range
mA[type][15] → cooldown
```

For rows/structures that do not enter that pipeline, trace the separate `oA` / special-action
consumer until HP subtraction and timing are proven.

**Success condition:** every `oA` building ID is assigned to a verified gameplay/effect path (combat, production/support, or utility), with any HP mutation, target rule, geometry, and timing traced to the exact consumer. Do not promote `oA[][7]` to universal Damage merely because it is an operand in some effect paths.


## 9. Document Workflow

```text
RESEARCH.md
    ↓
SOURCE_OF_TRUTH.md
    ↓
ROADMAP.md
    ↓
Godot implementation
```

`CHANGELOG.md` records corrections and important reclassifications.
