# STURMTRUPP MARS — SOURCE OF TRUTH

> Current-state reference. This file contains only the conclusions that are currently safe to
> use as reconstruction facts, plus explicitly marked unresolved items.
>
> For evidence and historical reasoning, see `RESEARCH.md`.
> For implementation order, see `ROADMAP.md`.

## Status vocabulary

- `ORIGINAL_CONFIRMED` — source and consumer/runtime semantics are demonstrated.
- `ORIGINAL_INFERRED` — strong interpretation, but not yet fully closed.
- `TEMPORARY_BALANCE` — placeholder for the remake; not original data.
- `UNRESOLVED` — do not treat as reconstructed original behavior.

---

## 1. Enemy combat data — CONFIRMED

### `rA`

```text
loader: HG.B(InputStream)
type:   int[9][16]
offset: 12984
rows:   enemy IDs 70–78
```

Confirmed fields:

| Field | Meaning | Status |
|---|---|---|
| `rA[][3]` | Enemy ID | ORIGINAL_CONFIRMED |
| `rA[][4]` | Enemy Damage | ORIGINAL_CONFIRMED |
| `rA[][5]` | Bullet resistance | ORIGINAL_CONFIRMED |
| `rA[][6]` | Energy resistance | ORIGINAL_CONFIRMED |
| `rA[][7]` | Fire resistance | ORIGINAL_CONFIRMED |
| `rA[][10]` | Reward/score-related | ORIGINAL_CONFIRMED |
| `rA[][12]` | Enemy attack range | ORIGINAL_CONFIRMED |
| `rA[][13]` | Movement speed | ORIGINAL_CONFIRMED |

The reconstructed enemy IDs are `70–78`.

## 2. Enemy resistance model — CONFIRMED

The three resistance components are:

```text
Bullet
Energy
Fire
```

The current Godot representation may use:

```gdscript
"resistance": {
    "bullet": ...,
    "energy": ...,
    "fire": ...
}
```

The exact values must come from the source table, not placeholders.

## 3. Building records — PARTIALLY CONFIRMED

```text
oA : int[12][9]
offset: 11518

IDs:
151, 153, 155, 157, 159, 161,
163, 165, 167, 169, 171, 173
```

Confirmed:

- Building Max HP — `ORIGINAL_CONFIRMED`
- Building Cost — `ORIGINAL_CONFIRMED`

Not confirmed universally:

- Turret Damage
- Turret Range
- Turret Fire Rate

## 4. `mA` — CURRENT VERIFIED INTERPRETATION

```text
loader: HG.B(InputStream)
type:   int[45][19]
offset: 7562
```

The previous hypothesis that `mA[][4]` / `mA[][5]` were the primary
Damage/Range candidates is superseded by the 2026-09-23 forensic pass.

### Runtime-confirmed conventional `lA` combat fields

| Field | Meaning | Status |
|---|---|---|
| `mA[][6]` | damage component matched to `rA[][5]` (Bullet resistance) | ORIGINAL_CONFIRMED |
| `mA[][7]` | damage component matched to `rA[][6]` (Energy resistance) | ORIGINAL_CONFIRMED |
| `mA[][8]` | damage component matched to `rA[][7]` (Fire resistance) | ORIGINAL_CONFIRMED |
| low16 `mA[][14]` | target/engagement range used by conventional `lA` combat | ORIGINAL_CONFIRMED |
| `mA[][15]` | attack cooldown / interval added to runtime timer `lA[][19]` | ORIGINAL_CONFIRMED |

Confirmed damage chain:

```text
mA[type][6..8]
    ↓
L(type, component)
    ↓
A(lA_entity, component)
    ↓
A(attacker, target)
    ↓
rA[target_profile][5..7] resistance reduction
    ↓
Y(attacker, target)
    ↓
vA[target][22] -= calculated_damage
```

Confirmed range chain:

```text
low16 mA[type][14]
    ↓
N(type)
    ↓
D(lA_entity)
    ↓
MA() / RA() target-area tests
    ↓
target assignment / line-of-sight validation
```

Confirmed cooldown chain:

```text
mA[type][15]
    ↓
Y(attacker, target)
    ↓
lA[attacker][19] += cooldown
```

`MA()` also skips the attack/target-acquisition branch while `lA[][19] > 0`,
which closes the runtime timer role.

### Fields `[4]` and `[5]`

The UI consumer displays:

```text
mA[type][4]  with HG.I(3) = "ОЖ"
mA[type][5]  with HG.I(2) = "О"
mA[type][6..8] with HG.I(1) = "А"
low16 mA[type][14] with HG.I(4) = "Р"
```

UI labels are not accepted as gameplay proof by themselves.

Therefore:

```text
mA[][4] → HP/life-related candidate, ORIGINAL_INFERRED
mA[][5] → exact semantics UNRESOLVED; no longer treated as Damage/Range candidate
```

`mA[][5]` is also consumed through `M(int)` / `C(int[])` in spatial/path
logic, so its previous classification as a primary turret attack stat is rejected.

### Rows 36..44 / category blocks 13..15

For these nine rows the source data contains:

```text
mA[][6..8] = 0,0,0
low16 mA[][14] = -1
mA[][15] = -1
```

Thus these rows do **not** use the conventional `mA → lA` attack chain above.
Any damage/range behavior associated with structures mapped to these rows must be
traced through a separate static/special-effect consumer path.


## 5. Building/static-effect consumers — updated 2026-09-23

The `oA` block is **not** a universal turret table. However, several per-index consumers now have direct HP-mutation proof.

Confirmed special/static-effect paths:

| Building ID | `oA` index | Direct consumer | Proven effect | Status |
|---:|---:|---|---:|---|
| 155 | 2 | `C.P()` | `vA[][22] -= 750` inside effect zone | ORIGINAL_CONFIRMED |
| 157 | 3 | `C.M()` | special hit can set target `vA[][22] = 0` | ORIGINAL_CONFIRMED special effect; numeric Damage UNRESOLVED |
| 159 | 4 | `C.O()` | `vA[][22] -= 800` inside effect zone | ORIGINAL_CONFIRMED |
| 161 | 5 | `C.O()` | `vA[][22] -= 1000` inside effect zone | ORIGINAL_CONFIRMED |
| 173 | 11 | `C.P()` | `vA[][22] -= 4000` inside effect zone | ORIGINAL_CONFIRMED |

Historical values:

```text
155 → 125   REJECTED as direct effect damage
173 → 200   REJECTED as direct effect damage
```

The current source consumers use `750` and `4000` respectively. The old values remain only in `RESEARCH.md` as historical/rejected evidence.

For IDs `151,153,163,165,167,169,171`, no direct HP subtraction was found in the audited `oA` state switch. This is a negative result for that consumer, not proof that every possible action path is exhausted.

## 6. `oA[][7]`

`oA[][7]` participates in UI/debug lookup, but its universal interpretation as a building
category is **not proven**.

Therefore:

```text
oA[][7] ≠ automatically mA category
```

Do not use that assumption to map all twelve building IDs.

## 7. Current unresolved forensic chain

The former target:

```text
category 13/14/15 → mA[type][4/5] → Damage/Range
```

is superseded.

The next unresolved chain is now:

```text
building ID 151..173
    ↓
runtime construction / spawn / upgrade path
    ↓
actual lA/mA type (if any)
    ↓
classify combat path:
    ├─ conventional mA[6..8] / mA[14] / mA[15]
    └─ oA / special / static-effect path
    ↓
prove per-building Damage / Range / Cooldown
```

Priority is now to map the twelve `oA` indices through the real activation/event path (`HG → C.F(index)`) and classify each ID as combat/effect, production/support, or utility before attempting a universal `TurretStats` table.


## 8. Rules for future findings

A new value is not promoted to `ORIGINAL_CONFIRMED` merely because:

- it matches a plausible number;
- it appears in a UI field;
- it appears in a building row;
- it resembles an enemy value;
- it fits a hypothesized category.

Promotion requires a demonstrated consumer/runtime chain.

