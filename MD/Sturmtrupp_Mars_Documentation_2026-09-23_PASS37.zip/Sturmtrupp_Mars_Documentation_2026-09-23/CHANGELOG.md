# STURMTRUPP MARS — CHANGELOG / RESEARCH CORRECTIONS

## 2026-09-22 — Documentation split

The former single `Sturmtrupp_Mars_Roadmap_v10.md` was reorganized into:

- `ROADMAP.md` — normative development plan.
- `SOURCE_OF_TRUTH.md` — current confirmed/unresolved reconstruction state.
- `RESEARCH.md` — complete forensic archive, preserving the original document.
- `CHANGELOG.md` — important corrections and reclassifications.

No original research material was discarded; the complete original file is preserved in `RESEARCH.md`.

## Important forensic corrections preserved from the original research

### Turret/static damage classification

Earlier material associated:

```text
155 → 125
173 → 200
```

with building/static damage.

Later forensic work established that these are special-action/static-effect damage paths and
must not be treated as universal turret Damage.

### `rA` classification

`rA` is the enemy combat matrix:

```text
int[9][16]
offset 12984
enemy IDs 70–78
```

It must not be copied to the twelve building IDs.

### `oA[][7]`

The earlier assumption that `oA[][7]` universally identifies an `mA` category was rejected.
It participates in UI/debug lookup, but the universal category mapping remains unproven.

### `mA`

`mA[type][4]` and `mA[type][5]` remain attack-stat candidates for defensive categories
13/14/15, but UI usage does not by itself prove Damage/Range semantics.

### Current research priority

The next required chain is:

```text
category 13/14/15
→ mA[type][4/5]
→ all consumers
→ target selection
→ range
→ damage
→ cooldown
→ building ID mapping
```

This correction history is intentionally kept separate from the normative roadmap so that old
hypotheses remain visible without becoming current implementation requirements.


## 2026-09-23 — Research Pass 36: `mA` combat semantics corrected

### Confirmed

For the conventional `lA → vA` combat path:

```text
mA[][6]       → Bullet damage component
mA[][7]       → Energy damage component
mA[][8]       → Fire damage component
low16 mA[][14] → target/engagement range
mA[][15]      → attack cooldown / interval
```

The damage chain reaches `vA[target][22] -= damage`, range reaches target acquisition/
validation in `MA()` / `RA()`, and cooldown reaches runtime timer `lA[][19]`.

### Rejected

The previous research direction:

```text
mA[][4] / mA[][5] → primary Damage / Range candidates
```

is rejected.

### Reclassified

```text
mA[][4] → UI-labelled "ОЖ"; HP/life-related candidate, ORIGINAL_INFERRED
mA[][5] → exact semantics UNRESOLVED
```

### Important data check

Rows 36..44 contain:

```text
mA[][6..8] = 0,0,0
low16 mA[][14] = -1
mA[][15] = -1
```

so the old `13/14/15 → [4/5] → Damage/Range` next-step chain is retired.

### New P0 target

```text
building IDs 151..173
→ runtime construction/spawn/upgrade mapping
→ conventional lA/mA combat OR oA/static/special path
→ per-building Damage/Range/Cooldown
```


## 2026-09-23 — Research Pass 37: `oA` effect consumers corrected

### New confirmed activation edge

`HG.class` calls:

```text
C.F(index)
```

from the UI/event action table. `C.F(index)` initializes the runtime state:

```text
oA[index][8] = oA[index][3]
```

Therefore the special `oA` consumers are reachable runtime paths; the earlier C-only call-site search was incomplete because it did not include `HG.class` callers.

### Corrected direct damage values

The bytecode now directly proves:

```text
155 → oA[2][7]  = 750 → vA[][22] -= 750
159 → oA[4][7]  = 800 → vA[][22] -= 800
161 → oA[5][7]  = 1000 → vA[][22] -= 1000
173 → oA[11][7] = 4000 → vA[][22] -= 4000
```

The historical entries:

```text
155 → 125
173 → 200
```

are rejected as direct effect damage and must not be used by the remake.

### Building 157 special effect

`oA` index 3 / building ID 157 reaches `C.M()`'s projectile-hit consumer. When the special state is active, the target's `vA[][22]` can be set to `0`.

This proves a special zero-HP effect but does **not** prove a numeric Damage value of `250`; `oA[3][7]` is not the operand of that HP mutation.

### Current status

```text
Confirmed special-effect damage: 155, 159, 161, 173
Confirmed special zero-HP effect: 157
Damage unresolved: 151, 153, 163, 165, 167, 169, 171
Universal Range: unresolved
Universal Fire Rate: unresolved
```

The next forensic target is the complete `HG action table → C.F(index) → oA state → consumer` mapping for all 12 indices.
